package Classes

interface Classes {
    fun definirClasse()
}