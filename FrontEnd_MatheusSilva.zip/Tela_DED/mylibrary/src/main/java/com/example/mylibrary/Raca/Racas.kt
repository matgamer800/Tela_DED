package Raca

interface Racas {
    fun definirRaca()
    fun HabilidadeRaca() : Array<Int>

}