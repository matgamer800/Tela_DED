package Classes

class Barbaro : Classes{
    override fun definirClasse() {
        print("Barbaro")
    }
}