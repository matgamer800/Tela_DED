package Lib.Raca

interface Racas {
    fun definirRaca()
    fun HabilidadeRaca() : Array<Int>
    fun AtributosAdd() : String

}