package Lib.Classes

interface Classes {
    fun definirClasse()
}