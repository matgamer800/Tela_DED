package Lib.Classes

class Barbaro : Classes{
    override fun definirClasse() {
        print("Barbaro")
    }
}